<!-- partial:partials/_sidebar.html -->
<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="#">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <!-- <li class="nav-item"> -->
            <!-- <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="mdi mdi-circle-outline menu-icon"></i>
              <span class="menu-title">Products</span>
              <i class="menu-arrow"></i>
            </a> -->
            <!-- <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="{{ url('admin/products/create') }}">Add Products</a></li>
                <li class="nav-item"> <a class="nav-link" href="{{ url('admin/products') }}">View Products</a></li>
              </ul>
            </div>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/alternatif') }}">
              <i class="mdi mdi-database menu-icon"></i>
              <span class="menu-title">Data Warga</span>
            </a> -->
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/kriteria') }}">
              <i class="mdi mdi-view-headline menu-icon"></i>
              <span class="menu-title">Kriteria</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/alternatif') }}">
              <i class="mdi mdi-file menu-icon"></i>
              <span class="menu-title">Alternatif</span>
            </a>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/colors') }}">
              <i class="mdi mdi-chart-pie menu-icon"></i>
              <span class="menu-title">Nilai Alternatif</span>
            </a>
          </li> -->
          <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/perhitungan') }}">
              <i class="mdi mdi-chart-pie menu-icon"></i>
              <span class="menu-title">Perhitungan</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="mdi mdi-circle-outline menu-icon"></i>
              <span class="menu-title">Users</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="{{ url('admin/products/create') }}">Tambah User</a></li>
                <li class="nav-item"> <a class="nav-link" href="{{ url('admin/products') }}">Daftar User</a></li>
              </ul>
            </div>
          </li>
          <!-- <li class="nav-item">
            <a class="nav-link" href="{{ url('admin/sliders') }}">
              <i class="mdi mdi-view-carousel menu-icon"></i>
              <span class="menu-title">Home Slider</span>
            </a>
          </li> -->
          <!-- <li class="nav-item">
            <a class="nav-link" href="documentation/documentation.html">
            <i class="mdi mdi-settings menu-icon"></i>
              <span class="menu-title">Site Setting</span>
            </a>
          </li> -->
        </ul>
      </nav>