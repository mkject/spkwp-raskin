

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4> Edit Data Alternatif
                    <a href="<?php echo e(url('admin/alternatif')); ?>" class="btn btn-primary btn-sm text-white float-end">Back</a>
                </h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url('admin/alternatif/'.$alternatives->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <!-- <div class="row"> -->
                        <div class="col-md-6 mb-3">
                            <label>Name Alternatif</name>
                            <input type="text" name="alternatif" value="<?php echo e($alternatives->alternatif); ?>" class="form-control"/>
                            <?php $__errorArgs = ['alternatif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>C1 Kondisi Rumah</label>
                            <select name="c1_alternatif" class="form-control">
                            <option value="<?php echo e($alternatives->c1); ?>"><?php echo e($alternatives->c1); ?></option>
                                <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kepentingan->nilai); ?>"><?php echo e($kepentingan->keterangan); ?></option>
                                    <?php $__errorArgs = ['c1_alternatif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>C2 Pekerjaan</label>
                            <select name="c2_alternatif" class="form-control">
                                <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kepentingan->id); ?>"><?php echo e($kepentingan->keterangan); ?></option>
                                    <?php $__errorArgs = ['c2_alternatif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>C3 Penghasilan</label>
                            <select name="c3_alternatif" class="form-control">
                                <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kepentingan->id); ?>"><?php echo e($kepentingan->keterangan); ?></option>
                                    <?php $__errorArgs = ['c3_alternatif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>C4 Umur</label>
                            <select name="c4_alternatif" class="form-control">
                                <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kepentingan->id); ?>"><?php echo e($kepentingan->keterangan); ?></option>
                                    <?php $__errorArgs = ['c4_alternatif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label>C5 Jumlah Tanggungan</label>
                            <select name="c5_alternatif" class="form-control">
                                <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kepentingan->id); ?>"><?php echo e($kepentingan->keterangan); ?></option>
                                    <?php $__errorArgs = ['c5_alternatif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <small class="text-danger"><?php echo e($message); ?></small> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="col-md-6 mb-3">
                            <button type="submit" class="btn btn-primary float-end"> Simpan </button>
                        </div>
                    <!-- </div> -->
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spkwp-raskin\spkwp-raskin\resources\views/admin/alternatif/edit.blade.php ENDPATH**/ ?>