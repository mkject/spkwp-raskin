

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

        <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?> </div>
        <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4> Kriteria
                        <a href="<?php echo e(url('admin/alternatif')); ?>" class="btn btn-warning btn-sm float-end">Kembali</a>
                    </h4>
                </div>
                <div class="card-body">
                    <h5 class="text-center mb-3">Matriks Alternatif - Kriteria</h5>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Alternatif</th>
                                <th>C1 Konsidi Rumah</th>
                                <th>C2 Pekerjaan</th>
                                <th>C3 Penghasilan</th>
                                <th>C4 Umur</th>
                                <th>C5 Jumlah Tanggungan</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $n = 1 ?>
                            <?php $__currentLoopData = $alternatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($n++); ?></td>
                                <td><?php echo e($alternative->alternatif); ?></td>
                                <td><?php echo e($alternative->c1); ?></td>
                                <td><?php echo e($alternative->c2); ?></td>
                                <td><?php echo e($alternative->c3); ?></td>
                                <td><?php echo e($alternative->c4); ?></td>
                                <td><?php echo e($alternative->c5); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <div class="card-body">
                    <h5 class="text-center mb-3">Perhitungan Bobot Kepentingan</h5>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th></th>
                                <th>K1</th>
                                <th>K2</th>
                                <th>K3</th>
                                <th>K4</th>
                                <th>K5</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Bobot Kepentingan</td>
                                <?php $nil = 0 ?>
                                <?php $__empty_1 = true; $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($criteria->kepentingan == $kepentingan->id ): ?>
                                            <td><?php echo e($kepentingan->nilai); ?></td>
                                            <?php $nil = $nil + $kepentingan->nilai  ?>
                                            <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td colspan="7">Tidak Ada Bobot</td>
                                <?php endif; ?>
                                <td><?php echo e($nil); ?></td>
                            </tr>
                            <tr>
                                <td>Kepentingan</td>
                                <?php $__currentLoopData = $hasilBobotKepentingan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bobotK): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($bobotK); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e(array_sum($hasilBobotKepentingan)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <div class="card-body">
                    <h5 class="text-center mb-3">Perhitungan Pangkat</h5>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th></th>
                                <th>K1</th>
                                <th>K2</th>
                                <th>K3</th>
                                <th>K4</th>
                                <th>K5</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Cost / Benefit</td>
                                <?php $__empty_1 = true; $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <td><?php echo e($criteria->cost_benefit); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td colspan="7">Tidak Ada</td>
                                <?php endif; ?>
                            </tr>
                            <tr>
                                <td>Kepentingan</td>
                                <td><?php echo e($bobotPangkat[0]); ?></td>
                                <td><?php echo e($bobotPangkat[1]); ?></td>
                                <td><?php echo e($bobotPangkat[2]); ?></td>
                                <td><?php echo e($bobotPangkat[3]); ?></td>
                                <td><?php echo e($bobotPangkat[4]); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                
                <div class="card-body">
                    <h5 class="text-center mb-3">Perhitungan Nilai S</h5>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Alternatif</th>
                                <th>S</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $n = 1 ?>
                            <?php $__currentLoopData = $vektorS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vektors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($n++); ?></td>
                                <td><?php echo e($vektors[1]); ?></td>
                                <td><?php echo e($vektors[0]); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th colspan=2>Jumlah</th>
                                <td><?php echo e($jumlahVektorS); ?></td>
                            </tr>
                           
                           
                        </tbody>
                        
                    </table>
                </div>

                <div class="card-body">
                    <h5 class="text-center mb-3">Hasil Akhir - Vektor V</h5>
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Alternatif</th>
                                <th>V</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $n = 1 ?>
                            <?php $__currentLoopData = $vektorS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vektors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($n++); ?></td>
                                <td><?php echo e($vektors[1]); ?></td>
                                <td><?php echo e($vektors[0]/$jumlahVektorS); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </tbody>
                    </table>
                </div>

                <!-- <div class="card-body">
                    <h5 class="text-center mb-3">Hasil Keputusan</h5> -->

                    <div class="col-md-12 grid-margin stretch-card">
                        <div class="card">
                            <div class="card-body">
                            <h4 class="card-title">Hasil Keputusan</h4>
                            <p class="card-description">Hasil perangkingan calon penerima beras (raskin)
                                 berdasarkan hasil akhir perhitungan Vektor V
                            <p class="card-description">Rangking Tertinggi adalah
                                  <code> 
                                    <?php $__currentLoopData = $hasilVektorV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x => $vektorv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($hasilVektorV[1][$x]); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </code> 
                                <div class="row">
                                    <div class="col-md-6 grid-margin stretch-card">
                                        <ol>
                                        <?php $__currentLoopData = $hasilVektorV; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x => $vektorv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($vektorv[0]); ?> . <?php echo e($vektorv[1]); ?> </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                    </div>

                                  

                                </div>

                            </div>
                        </div>
                    </div>

                <!-- </div> -->

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spkwp-raskin\spkwp-raskin\resources\views/admin/perhitungan/index.blade.php ENDPATH**/ ?>