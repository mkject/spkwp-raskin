

<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-md-12">

        <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?> </div>
        <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4> Kriteria
                        <a href="<?php echo e(url('admin/products/create')); ?>" class="btn btn-primary btn-sm float-end">Add Product</a>
                    </h4>
                </div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kriteria</th>
                                <th>Bobot</th>
                                <th>Atribut</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $n = 1 ?>
                            <?php $__empty_1 = true; $__currentLoopData = $criterias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $criteria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($n++); ?></td>
                                <td><?php echo e($criteria->kriteria); ?></td>
                                <?php $__currentLoopData = $kepentingans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kepentingan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($criteria->kepentingan == $kepentingan->id ): ?>
                                    <td><?php echo e($kepentingan->keterangan); ?></td>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($criteria->cost_benefit); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/kriteria/'.$criteria->id.'/edit')); ?>" class="btn btn-success">Edit</a>
                                    <a href="<?php echo e(url('admin/kriteria/id/delete')); ?>" onclick="return confirm('Are you sure want to delete this data?')" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">Tidak Ada Kriteria</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spkwp-raskin\spkwp-raskin\resources\views/admin/kriteria/index.blade.php ENDPATH**/ ?>