
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">

        <?php if(session('message')): ?>
            <div class="alert alert-success"> <?php echo e(session('message')); ?> </div>
        <?php endif; ?>
            <div class="card">
                <div class="card-header">
                    <h4> Data Alternatif
                        <a href="<?php echo e(url('admin/alternatif/create')); ?>" class="btn btn-primary btn-sm float-end">Tambah Data Alternatif</a>
                    </h4>
                </div>
                <div class="card-body">
                <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Alternatif</th>
                                <th>C1 Konsidi Rumah</th>
                                <th>C2 Pekerjaan</th>
                                <th>C3 Penghasilan</th>
                                <th>C4 Umur</th>
                                <th>C5 Jumlah Tanggungan</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $n = 1 ?>
                            <?php $__currentLoopData = $alternatives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alternative): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($n++); ?></td>
                                <td><?php echo e($alternative->alternatif); ?></td>
                                <td><?php echo e($alternative->c1); ?></td>
                                <td><?php echo e($alternative->c2); ?></td>
                                <td><?php echo e($alternative->c3); ?></td>
                                <td><?php echo e($alternative->c4); ?></td>
                                <td><?php echo e($alternative->c5); ?></td>
                                <td>
                                    <a href="<?php echo e(url('admin/alternatif/'.$alternative->id.'/edit')); ?>" class="btn btn-success">Edit</a>
                                    <a href="<?php echo e(url('admin/alternatif/'.$alternative->id.'/delete')); ?>" onclick="return confirm('Are you sure want to delete this data?')" class="btn btn-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\spkwp-raskin\spkwp-raskin\resources\views/admin/alternatif/index.blade.php ENDPATH**/ ?>