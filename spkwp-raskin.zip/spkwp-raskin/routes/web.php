<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Auth::routes();

// Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// Route::prefix('admin')->middleware(['auth','isAdmin'])->group(function () {
Route::prefix('admin')->group(function () {

    Route::get('dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'index']);

    // Route::get('/brands', App\Http\Livewire\Admin\Brand\Index::class);

     // Kriteria routes
     Route::controller(App\Http\Controllers\Admin\KriteriaController::class)->group(function (){
        Route::get('/kriteria', 'index');
        // Route::get('/category/create', 'create');
        // Route::post('/category', 'store');
        Route::get('/kriteria/{kriteria}/edit', 'edit');
        Route::put('/kriteria/{kriteria_id}', 'update');
    });

    // Alternative routes
    Route::controller(App\Http\Controllers\Admin\AlternativeController::class)->group(function (){
        Route::get('/alternatif', 'index');
        Route::get('/alternatif/create', 'create');
        Route::post('/alternatif', 'store');
        Route::get('/alternatif/{alternatif}/edit', 'edit');
        Route::put('/alternatif/{alternatif}', 'update');
    });

     // Perhitungan routes
     Route::controller(App\Http\Controllers\Admin\PerhitunganController::class)->group(function (){
        Route::get('/perhitungan', 'index');
        Route::get('/perhitungan/create', 'create');
        Route::post('/perhitungan', 'store');
        Route::get('/perhitungan/{perhitungan}/edit', 'edit');
        Route::put('/perhitungan/{perhitungan_id}', 'update');

        Route::post('product-color/{product_color_id}', 'updateProductColorQty');
        Route::get('admin/product-color/{product_color_id}/delete', 'deleteProductColorQty');
        // Route::post('/produk/{product_color_id}', 'tes');
        // Route::get('/colors/{product_color_id}/delete', 'destroy');

    });

    // Colors routes
    Route::controller(App\Http\Controllers\Admin\ColorController::class)->group(function (){
        Route::get('/colors', 'index');
        Route::get('/colors/create', 'create');
        Route::post('/colors/create', 'store');
        Route::get('/colors/{color}/edit', 'edit');
        Route::put('/colors/{color_id}', 'update');
        Route::get('/colors/{color_id}/delete', 'destroy');
    });

    // Slider routes
    Route::controller(App\Http\Controllers\Admin\SliderController::class)->group(function (){
        Route::get('/sliders', 'index');
        Route::get('/sliders/create', 'create');
        Route::post('/sliders/create', 'store');
        // Route::post('/sliders', 'store');
        // Route::get('/sliders/{color}/edit', 'edit');
        // Route::put('/sliders/{color_id}', 'update');
        // Route::get('/sliders/{color_id}/delete', 'destroy');
    });

});