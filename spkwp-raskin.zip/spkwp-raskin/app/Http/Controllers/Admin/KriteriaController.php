<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Criteria;
use App\Models\Kepentingan;
use App\Http\Requests\CriteriaFormRequest;

class KriteriaController extends Controller
{
    public function index() 
    {
        $kepentingans = Kepentingan::all();
        $criterias = Criteria::all();
        return view('admin.kriteria.index', compact('criterias', 'kepentingans'));
    }

    public function edit(int $criteria_id)
    {
        $kepentingans = Kepentingan::all();
        $criteria = Criteria::findOrFail($criteria_id);
        return view('admin.kriteria.edit', compact('criteria', 'kepentingans'));
    }

    public function update(CriteriaFormRequest $request, int $kriteria_id)
    {
        // dd($kriteria_id);

        $validatedData = $request->validated();
        // $kriteria = Kepentingan::findOrFail($validatedData['kepentingan_id'])->criteriaFk()->where('id', $kriteria_id)->first();
        $kriteria = Criteria::findOrFail($kriteria_id);

        // dd($kriteria);

        if($kriteria) {
            $kriteria->update([
                'kriteria' => $validatedData['kriteria'],
                'kepentingan' => $validatedData['kepentingan_id'],
                'cost_benefit' => $validatedData['cost_benefit']
            ]);
            return redirect('/admin/kriteria')->with('message', 'Data kriteria berhasil diperbarui');
        } else {
            return redirect('/admin/kriteria')->with('message', 'Kriteria ID tidak ditemukan!');
        }
    }

}
