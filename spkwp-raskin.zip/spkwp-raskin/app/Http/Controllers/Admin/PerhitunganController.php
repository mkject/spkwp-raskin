<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Criteria;
use App\Models\Alternative;
use App\Models\Kepentingan;


class PerhitunganController extends Controller
{
    public function index() 
    {
        $alternatives = Alternative::all();
        $criterias = Criteria::all();
        $kepentingans = Kepentingan::all();
        // $sum_criterias = $criterias->sum('kepentingan');
        $hasilBobotKepentingan = [];
        $bobotPangkat = [];
        $vektorS = [];

        // dd($sum_criterias);

        $jumlahNilaiKriteria = 0;
        $hasilNilaiKriteria = 0;

        // mencari jumlah kriteria
        foreach($criterias as $criteria) {
            foreach($kepentingans as $kepentingan) {
                if ($criteria->kepentingan == $kepentingan->id) {
                    $jumlahNilaiKriteria += $kepentingan->nilai;
                }
            }
        }

        foreach($criterias as $criteria) {
            foreach($kepentingans as $kepentingan) {
                if ($criteria->kepentingan == $kepentingan->id) {
                    $hasilBobotKepentingan[] = $kepentingan->nilai/$jumlahNilaiKriteria;
                    if($criteria->cost_benefit == 'Cost') {
                        $bobotPangkat[] = $kepentingan->nilai/$jumlahNilaiKriteria*(-1);
                    } else {
                        $bobotPangkat[] = $kepentingan->nilai/$jumlahNilaiKriteria*1;
                    }
                }
            }
        }

        // mencari vektor S
        $vektorS = [];
        $jumlahVektorS = 0;
        $alternatives2 = Alternative::get()->toArray();
        for($i=0; $i < count($alternatives2); $i++) {
            for($j=0; $j < count($bobotPangkat); $j++) {
                $s1[$i][$j] = pow(($alternatives2[$i]['c1']), $bobotPangkat[$j]);
                $s2[$i][$j] = pow(($alternatives2[$i]['c2']), $bobotPangkat[$j]);
                $s3[$i][$j] = pow(($alternatives2[$i]['c3']), $bobotPangkat[$j]);
                $s4[$i][$j] = pow(($alternatives2[$i]['c4']), $bobotPangkat[$j]);
                $s5[$i][$j] = pow(($alternatives2[$i]['c5']), $bobotPangkat[$j]);
            }
            $SumVektorS[$i] = $s1[$i][0]*$s2[$i][1]*$s3[$i][2]*$s4[$i][3]*$s5[$i][4];           
            $vektorS[$i] = [$s1[$i][0]*$s2[$i][1]*$s3[$i][2]*$s4[$i][3]*$s5[$i][4], $alternatives[$i]['alternatif']]; 
            // echo "<td>".round($vektorS[$i],6)."</td></tr>";
            $jumlahVektorS += $SumVektorS[$i];
        }

        $jumlahVektorV = 0;
        $hasilVektorV = [];
        foreach($vektorS as $ki => $vektors) {
            $hasilVektorV[] = [$vektors[1], round($vektors[0]/$jumlahVektorS, 6)];
        }
        // dd($hasilVektorV);
        
        krsort($hasilVektorV);
        foreach($hasilVektorV as $x => $vektorv) {
            // echo $vektorv[0];
            echo $hasilVektorV[1][$x];
        }
        // dd($hasilVektorV);
        return view('admin.perhitungan.index', compact('alternatives', 'criterias', 'hasilBobotKepentingan',
                                                        'kepentingans', 'bobotPangkat', 'vektorS', 
                                                        'jumlahVektorS', 'hasilVektorV'));
    }

    public function hitungBobotKepentingan()
    {

    }

    public function edit(int $criteria_id)
    {
        $kepentingans = Kepentingan::all();
        $criteria = Criteria::findOrFail($criteria_id);
        return view('admin.kriteria.edit', compact('criteria', 'kepentingans'));
    }

    public function update(CriteriaFormRequest $request, int $kriteria_id)
    {
        // dd($kriteria_id);

        $validatedData = $request->validated();
        // $kriteria = Kepentingan::findOrFail($validatedData['kepentingan_id'])->criteriaFk()->where('id', $kriteria_id)->first();
        $kriteria = Criteria::findOrFail($kriteria_id);

        // dd($kriteria);

        if($kriteria) {
            $kriteria->update([
                'kriteria' => $validatedData['kriteria'],
                'kepentingan' => $validatedData['kepentingan_id'],
                'cost_benefit' => $validatedData['cost_benefit']
            ]);
            return redirect('/admin/kriteria')->with('message', 'Data kriteria berhasil diperbarui');
        } else {
            return redirect('/admin/kriteria')->with('message', 'Kriteria ID tidak ditemukan!');
        }
    }

}
