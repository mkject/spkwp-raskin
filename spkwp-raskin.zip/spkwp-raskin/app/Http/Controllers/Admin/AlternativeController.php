<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Kepentingan;
use App\Models\Alternative;
use App\Http\Requests\AlternativeRequest;

class AlternativeController extends Controller
{
    
    public function index() 
    {
        $alternatives = Alternative::all();
        return view('admin.alternatif.index', compact('alternatives'));
    }
    public function edit(int $alternatif_id)
    {
        $kepentingans = Kepentingan::all();
        $alternatives = Alternative::findOrFail($alternatif_id);
        return view('admin.alternatif.edit', compact('alternatives', 'kepentingans'));
    }

    public function update(AlternativeRequest $request, int $alternatif_id)
    {
        $validatedData = $request->validated();
        $alternatif = Alternative::findOrFail($alternatif_id);

        if($alternatif) {
            $alternatif->update([
                'alternatif' => $validatedData['alternatif'],
                'c1' => $validatedData['c1_alternatif'],
                'c2' => $validatedData['c2_alternatif'],
                'c3' => $validatedData['c3_alternatif'],
                'c4' => $validatedData['c4_alternatif'],
                'c5' => $validatedData['c5_alternatif'],
            ]);

            return redirect('/admin/alternatif')->with('message', 'Data alternatif berhasil diperbarui');
        } else {
            return redirect('/admin/alternatif')->with('message', 'Alternatif ID tidak ditemukan!');
        }
    }

}
